local loader = loadfile("loader.lua")() -- run the loader first

local library = loadstring(game:HttpGet("https://pastebin.com/raw/FsJak6AT"))() -- replace with your UI lib
local ESP = require(script.modules.esp_module)
local AimAssist = require(script.modules.aim_module)

local window = library:CreateWindow("ALCATRAZ-PF")

local espEnabled = false
local aimAssistEnabled = false
local fovCircleEnabled = false

window:AddToggle("ESP", false, function(state)
    espEnabled = state
    if state then ESP:Enable() else ESP:Disable() end
end)

window:AddToggle("Aim Assist", false, function(state)
    aimAssistEnabled = state
    if state then AimAssist:Enable() else AimAssist:Disable() end
end)

window:AddToggle("FOV Circle", false, function(state)
    fovCircleEnabled = state
    -- Add or remove FOV circle drawing
end)

window:AddButton("Unload Script", function()
    espEnabled = false
    aimAssistEnabled = false
    fovCircleEnabled = false
    ESP:Disable()
    AimAssist:Disable()
    print("Script unloaded.")
end)

local UIS = game:GetService("UserInputService")
UIS.InputBegan:Connect(function(input, gameProcessed)
    if gameProcessed then return end
    if input.KeyCode == Enum.KeyCode.RightShift then
        library:ToggleUI()
    end
end)

game:GetService("RunService").RenderStepped:Connect(function()
    if espEnabled then
        -- Update ESP visuals
    end
    if aimAssistEnabled then
        -- Update Aim logic
    end
    if fovCircleEnabled then
        -- Draw/update FOV circle
    end
end)