local loadWindow = loadstring(game:HttpGet("https://raw.githubusercontent.com/paysonism/ALCATRAZ-PF/refs/heads/main/ui/load_window.lua"))()
loadWindow:show("Loading ALCATRAZ-PF...")

wait(2)

loadWindow:update("Initializing modules...")
wait(1)

loadWindow:close()