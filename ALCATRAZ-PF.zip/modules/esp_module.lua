local ESP = {}

function ESP:Enable()
    print("ESP Enabled")
    -- Initialize ESP drawing
end

function ESP:Disable()
    print("ESP Disabled")
    -- Cleanup drawings
end

return ESP